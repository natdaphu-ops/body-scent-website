# MOON HAIR CARE — โปรเจกต์เว็บไซต์ร้านแชมพู

เว็บไซต์ตัวอย่างสำหรับงาน LSM496: ร้านค้าออนไลน์ 2 SKUs พร้อมตะกร้าสินค้า ใบจัดเตรียมสินค้า (Packing Slip) และจุดเชื่อมต่อ Google Sheets

## ไฟล์ในโปรเจกต์
- `index.html` หน้าเว็บไซต์
- `styles.css` รูปแบบและการจัดวาง
- `app.js` แสดงสินค้า ตะกร้า สั่งซื้อ และพิมพ์ใบจัดเตรียมสินค้า
- `config.js` ตั้งค่า URL ของ Google Apps Script
- `google-apps-script.gs` โค้ดเชื่อม Google Sheets
- `MOON_HAIR_CARE_Sheets_Template.xlsx` แม่แบบชีตสินค้าและคำสั่งซื้อ

## วิธีทดลองทันที
เปิด `index.html` ในเบราว์เซอร์ได้เลย เว็บไซต์จะใช้ข้อมูลตัวอย่าง 2 SKU และสร้างใบจัดเตรียมสินค้าให้ทดลองพิมพ์ได้ โดยยังไม่บันทึกลง Google Sheets

## เชื่อม Google Sheets
1. อัปโหลดไฟล์ `MOON_HAIR_CARE_Sheets_Template.xlsx` ไปยัง Google Drive
2. เปิดด้วย Google Sheets
3. ไปที่ Extensions > Apps Script
4. คัดลอกโค้ดจาก `google-apps-script.gs` ไปวาง
5. นำ Spreadsheet ID จาก URL ของ Google Sheet ไปใส่แทน `ใส่_ID_ของ_GOOGLE_SHEET_ที่นี่`
6. กด Save
7. เลือก Deploy > New deployment > Web app
8. Execute as: Me และ Who has access: Anyone (หรือค่าที่อาจารย์กำหนด)
9. กด Deploy และอนุญาตสิทธิ์ตามขั้นตอน จากนั้นคัดลอก Web app URL
10. เปิด `config.js` ใส่ URL ใน `GOOGLE_SCRIPT_URL` และเปลี่ยน `USE_DEMO_DATA` เป็น `false`

หมายเหตุ: การตั้งค่า Anyone ทำให้ผู้ที่มี URL เรียกใช้ Web App ได้ ควรใช้กับชีตสำหรับงานเรียนที่ไม่มีข้อมูลส่วนบุคคลจริงเท่านั้น และทดสอบด้วยข้อมูลสมมติ

## อัปโหลด GitHub
1. เข้า https://github.com แล้วสร้าง repository ใหม่ เช่น `moon-hair-care`
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ (ไม่จำเป็นต้องอัปโหลดไฟล์ ZIP)
3. กด Commit changes

## เผยแพร่ด้วย Vercel
1. เข้า https://vercel.com และ Sign up / Log in ด้วย GitHub
2. กด Add New > Project แล้วเลือก repository `moon-hair-care`
3. Framework Preset เลือก Other
4. Build Command และ Output Directory ปล่อยว่างได้ (หรือ Output Directory เป็น `.`)
5. กด Deploy
6. เมื่อเสร็จจะได้ URL เว็บไซต์สำหรับส่งอาจารย์

## สิ่งที่สาธิตกับอาจารย์
1. หน้าแรกและรายละเอียดสินค้า 2 SKUs
2. กดเพิ่มสินค้าลงตะกร้าและปรับจำนวน
3. กรอกชื่อ เบอร์โทร และที่อยู่ผู้รับ
4. กดยืนยันคำสั่งซื้อ
5. แสดงใบจัดเตรียมสินค้า พร้อมรายการ จำนวน ยอดรวม และช่องตรวจสอบก่อนปิดกล่อง
6. กดพิมพ์ใบจัดเตรียมสินค้า
7. เมื่อเชื่อม Apps Script แล้ว คำสั่งซื้อจะถูกเพิ่มในแท็บ Orders และรายการสินค้าอ่านจากแท็บ Products

## ข้อจำกัดที่ควรแจ้ง
- เป็นเว็บเดโมเพื่อการศึกษา ไม่มีระบบชำระเงินออนไลน์หรือระบบขนส่งจริง
- การพิมพ์ใบจัดเตรียมสินค้าเป็นการสร้างเอกสารสำหรับแพ็กสินค้า ไม่ใช่ใบปะหน้าขนส่งที่มีเลข Tracking
- ราคาและคุณสมบัติสินค้าเป็นข้อมูลสมมติสำหรับงานเรียน
