// Google Apps Script สำหรับ MOON HAIR CARE
// สร้าง Google Sheet ที่มีแท็บชื่อ Products และ Orders
// Products: sku | name | subtitle | description | price | volume | type | active
// Orders: orderNo | createdAt | customer | phone | address | items | total | status

const SPREADSHEET_ID = "ใส่_ID_ของ_GOOGLE_SHEET_ที่นี่";

function doGet() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName("Products");
  const values = sheet.getDataRange().getValues();
  const headers = values.shift();
  const products = values
    .filter(row => row[0] && String(row[7]).toLowerCase() !== "false")
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = row[i]);
      return obj;
    });
  return ContentService.createTextOutput(JSON.stringify({products}))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const data = JSON.parse(e.postData.contents);
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName("Orders");
  sheet.appendRow([
    data.orderNo, data.createdAt, data.customer, data.phone,
    data.address, JSON.stringify(data.items), data.total, "รอจัดเตรียม"
  ]);
  return ContentService.createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}