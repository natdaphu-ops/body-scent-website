// ตั้งค่าหลังจากสร้าง Google Apps Script Web App แล้ว
// วาง URL ของ Web App ในเครื่องหมายคำพูดด้านล่าง
window.MOON_CONFIG = {
  GOOGLE_SCRIPT_URL: "",
  // หากยังไม่ได้เชื่อม Google Sheets เว็บไซต์จะใช้ข้อมูลตัวอย่างใน app.js
  USE_DEMO_DATA: true
};